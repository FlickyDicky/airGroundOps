CREATE USER 'grops'@'localhost' IDENTIFIED BY 'admin';
GRANT ALL PRIVILEGES ON grops.* TO 'grops'@'localhost';
