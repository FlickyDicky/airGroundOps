CREATE DATABASE IF NOT EXISTS grops;
USE grops;

DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS roles;

CREATE TABLE roles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(3) NOT NULL
);

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role_id INT,
    FOREIGN KEY (role_id) REFERENCES roles(id)
);

INSERT INTO roles (name) VALUES ('VLY');
INSERT INTO roles (name) VALUES ('RYR');
INSERT INTO roles (name) VALUES ('A1');

-- Insert user for Vueling role
INSERT INTO users (username, password, role_id) VALUES ('vueling', 'admin', '1'); 

-- Insert user for Ryanair role
INSERT INTO users (username, password, role_id) VALUES ('ryanair', 'admin', '2'); 

-- Insert user for Admin role
INSERT INTO users (username, password, role_id) VALUES ('admin', 'admin', '3'); 