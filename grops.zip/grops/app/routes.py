from flask import render_template, request, session, redirect, url_for
from app import get_user_role, all_flights, vueling_flights, ryanair_flights
from app import app
from functools import wraps

# Define routes

# Define decorator function to check if the user is logged in
def login_required(func):
    @wraps(func)
    def decorated_function(*args, **kwargs):
        if session.get('user_role') is None:
            # Redirect to the login page if the user is not logged in
            return redirect(url_for('login_form'))
        return func(*args, **kwargs)
    return decorated_function

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login_form', methods=['GET', 'POST'])
def login_form():
    return render_template('login-form.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    # Check credentials and retrieve user role
    user_role = get_user_role(request.form['username'])

    # Store user role in session
    session['user_role'] = user_role

    # Redirect to dashboard
    return redirect(url_for('dashboard'))

@app.route('/logout')
@login_required
def logout():
    session.pop('user_role', None)
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    user_role = session.get('user_role')
    if user_role == 3:
        filtered_flights = all_flights()
    elif user_role == 1:
        filtered_flights = vueling_flights()
    elif user_role == 2:
        filtered_flights = ryanair_flights()
    else:
        # Handle unknown roles
        filtered_flights = []
        
    return render_template('dashboard.html', flights=filtered_flights)

