from flask import Flask
from flask_mysqldb import MySQL
import json 

# Create Flask application instance
app = Flask(__name__)

# Configure Flask app
app.config['SECRET_KEY'] = 'your_secret_key'
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'grops'
app.config['MYSQL_PASSWORD'] = 'admin'
app.config['MYSQL_DB'] = 'grops'

# Initialize Flask-MySQLdb
mysql = MySQL(app)

def get_user_role(username):
    # Fetch user's role from the database
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT role_id FROM users WHERE username = %s", (username,))
    user_role = cursor.fetchone()
    cursor.close()

    if user_role:
        return user_role[0]  # Return the role_name
    else:
        return None  # User not found or role not assigned

# Load JSON data
with open('vuelos.json', 'r') as f:
    flights_data = json.load(f)

def all_flights():
    # Retrieve all flights from the JSON data
    all_flights = []
    for flights in flights_data.values():
        all_flights.extend(flights)
        
    return all_flights

def vueling_flights():
    # Retrieve flights specific to Vueling airline from the JSON data
    return flights_data.get('vueling', [])

def ryanair_flights():
    # Retrieve flights specific to Ryanair airline from the JSON data
    return flights_data.get('ryanair', [])
# Import routes
from routes import * 
